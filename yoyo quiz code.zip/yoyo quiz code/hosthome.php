<html>
	<head>
		<title>yoyo Quiz | Homepage</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/design.css" />
		<style>img[alt="www.000webhost.com"]{display: none}</style>
	</head>


		<body>

					<div class="header">
					</div>

					<div class="navbar">
					  <a href="random.php">Random Quiz</a>
					  <a href="create_quiz_form.php">Custom Quiz</a>
					  <a href="list_of_title.php">View Quiz List</ap>
					  <a href="help.php" class="right">Help</a>
					  		<div class="dropdown">
					    		<button class="dropbtn">My Account

					    		</button>
					    		<div class="dropdown-content">
						     	 	<a href="profile.php">Profile</a>
						      		<a href="changepassword.php">Change Password</a>
						      		<a href="deleteaccount.php">Delete Account</a>
						      		<a href="signout.php">Sign Out</a>
					      		</div>
					  		</div>
						</div>
					</div>

					<div class="container">
						<img src="image/host_img.png">
  					<div class="text-block">
    				<h4>Quote of the Day</h4>
    				<p><i>"Work as hard as you can and then be happy in the knowledge you couldn’t have done any more.”</i></p>
  					</div>


					</div>
				<?php include("footer.html");

?>
		</body>
	</html>
