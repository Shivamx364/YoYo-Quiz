<html>
<head>
		<title>yoyo Quiz | Random Quiz | Sports</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/design.css" />
		<style>img[alt="www.000webhost.com"]{display: none}</style>
	</head>


		<body>

					<div class="header">
					  <a href="random.php"><h1>YoYo Quiz</h1></a>
					  <p>Learn With Fun</p>
					</div>

					<div class="navbar">
					  <a href="help.php" class="right">Help</a>
					  	<div class="dropdown">
					    	<button class="dropbtn">My Account
					     		 <i class="fa fa-caret-down"></i>
					    	</button>
					    		<div class="dropdown-content">
						     	 	<a href="#">Profile</a>
						      		<a href="#">Edit Profile</a>
						      		<a href="#">Change Password</a>
						      		<a href="#">Delete Account</a>
						      		<a href="signout.php">Sign Out</a>
					      		</div>
					  	</div>

					</div>
          <div class="sports">
            <h4 align='center'>Sports</h3>
          </div>
      </body>
    </html>
