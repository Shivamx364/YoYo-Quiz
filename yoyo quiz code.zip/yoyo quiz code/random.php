<html>
<head>
		<title>yoyo Quiz | Random Quiz</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/design.css" />
		<style>img[alt="www.000webhost.com"]{display: none}</style>
	</head>


		<body>

					<div class="header">

					</div>

					<div class="navbar">
					  <a href="help.php" class="right">Help</a>

					</div>

          <div><h3 align='center'>Choose Your Category</h3></div>
          <div class="cat"><a href="sports.php?sports=spt">Sports</a></div>
          <div class="cat"><a href="Sports.php?science=sci"> Science </a></div>
          <div class="cat"><a href="sports.php?gk=gkca"> General Knowlegde And Current Affairs</a></div>
          <div class="cat"><a href="sports.php?mythology=myth"> Mythology And History</a></div>

          </body>
    </html>
		<?php include("footer.html"); ?>
