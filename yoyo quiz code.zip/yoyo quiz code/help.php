<?php

?>
<html>
<head>
		<title>yoyo Quiz | Help</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/design.css" />
		<style>img[alt="www.000webhost.com"]{display: none}</style>
	</head>


		<body>

					<div class="header">

					</div>

					<div class="navbar">
					</div>
          <div class="help">
              <h1>Help Desk</h1>
              <p>YoYo Quiz will provide you learning with fun.  This project includes two modules:<br>
                  -Random Quiz<br>
                  -Custom Quiz<br>
              </p>
              <h2>Random Quiz</h2>
                <p>In YoYo quiz, you can play the quiz freely without login.
                  For playing random Quiz,<br>

                  click on the <b>Random Quiz</b>,<br>

                  then select the category of your choice from the given Categories.<br>

                  Once you click one of the category you will be forwarded to the Quiz page.<br>

              <p>

              <h2>Custom Quiz</h2>
              <h3>For Teacher</h3>
              <p>Only Teachers are eligible for creating the custom Quiz.for that You need to logged in as a Teacher.
                after logged into the page, <br>
                -Click on <b>Custom Quiz</b><br>

                -Choose the Format of Your Quiz <br>

                -create the Quiz<br>

              <h3>For Student</h3>
              <p>Students can only be able to participate in the custom quiz if he/she enters the correct code provided by the Teacher.<br>
                  -Click on <b>Enter Code</b><br>

                -Type the given Code and Join<br>

              </p>

            </div>
            </body>
  </html>
          <?php

include("footer.html");
?>
